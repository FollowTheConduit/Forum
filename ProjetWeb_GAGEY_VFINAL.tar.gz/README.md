Ce projet est une application web (forum) utilisant la librairie Flask, l'installation de celle-ci est donc nécessaire.

Pour initialiser la base de données : 
    - flask initdb

Et pour lancer l'application :
    - flask run